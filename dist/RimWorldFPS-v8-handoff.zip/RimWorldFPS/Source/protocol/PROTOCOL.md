# Bridge protocol v0

This is upstream RimWorld x MW2's protocol, unchanged except for the additions in
[FPS fork additions](#fps-fork-additions) at the end. "IW4L" below is the 3D side, which in
this fork is the boomer client (`boomer/`); "the MW2 player" is the first-person player.

One TCP connection on localhost (default `127.0.0.1:47820`). **IW4L listens, RimWorld connects**
and retries every 2 seconds, so either game can start first.

Each message is one JSON object on its own line, UTF-8, tagged by `"t"`. Unknown types are
logged and skipped, so either side can add messages without breaking the other.
Bump `protocol` in `hello` on any breaking change.

The Rust types in `bridge/crates/protocol` are the reference definition, and every line in
`examples.ndjson` is checked against them by `cargo test`.

## Authority

RimWorld is the source of truth. RimWorld → IW4L messages are state to render.
IW4L → RimWorld messages are reports and requests that RimWorld validates and applies.

## Messages

| `t` | Direction | Milestone | Meaning |
|---|---|---|---|
| `hello` | both | M0 | First message after connecting: `side`, `protocol`, optional `game_version`; from M9 RimWorld also sends `window`, its own window's Windows handle as a string (from M12 IW4L sends its own too, for "Control in MW2" to bring up), for Tab to bring up |
| `tick` | RW → IW4L | M0 | Heartbeat, RimWorld game tick, once per second at 1x |
| `snapshot` | RW → IW4L | M1 | About 10 a second, paused or not: optional `map` size `[x, z]`, and every spawned pawn on the map in view: `id`, `name`, `kind` (`humanlike`/`animal`/`mech`/`other`), `x`/`z`, `rot`, `stance`, `weapon`, `downed`, `faction` (`player`/`hostile`/`neutral`), and from M10 for people too, and for animals and mechs (M6), `art` (`[north, east, south]`, pictures in `textures`, -1 none; west is east mirrored) and `draw` (`[w, h]` in cells); from M2 also `player_pawn`, the drafted colonist the MW2 player plays as (from M12 only one RimWorld's "Control in MW2" handed over), with `player_speed` and `rate` (M12), and each pawn's optional `hurt` count (M12). From M15: `player_gun`, how the played colonist's gun fires (`burst` shots `between` seconds apart, then `cooldown` and `warmup` seconds, all game time); and per pawn `lie` (lying down: the head's angle clockwise from north, as RimWorld turns the body), `bed` (lying in a bed) and `carry` (what it carries: `tex`, a `_cut` picture, `size` in cells, and `pawn` when it is a person or animal). From M16 corpses too, lying (`lie`, `downed`) with `dead` true. From M18 `paused: true` while RimWorld is paused: IW4L holds its player still. From M20 `player_gun.throw`: the colonist holds grenades, thrown this many cells at most. From M23 `held`: the weapon in the pawn's hands where RimWorld shows it (drafted, aiming or attacking, always for enemies): `tex` (a `_cut` picture, pointing east), `size` `[w, h]` cells, `aim` (degrees clockwise from north, while aiming or attacking), `turn` (`equippedAngleOffset`), `reach` (`equippedDistanceOffset`), `melee`; and `swings`, how many melee attacks it has made (IW4L swings and lunges when it goes up) |
| `shot` | RW → IW4L | M2 | A bullet RimWorld fired, as it leaves the gun: `shooter`, `weapon`, `from`/`to` (`[x, height, z]`, `to` where it lands), `result` (`hit`/`miss`), optional `speed` (cells a second), `target`/`part`; from M8 `id`, the bullet's id. RimWorld no longer lets its bullets strike the colonist the MW2 player plays: IW4L flies each bullet (one aimed at that colonist at the player's middle and on past, until something solid stops it) and says which meet the player |
| `player_move` | IW4L → RW | M2 | About 10 a second while playing `pawn`: the MW2 player's `x`/`z` and `yaw` (degrees clockwise from north). RimWorld moves the pawn there when the cell is walkable |
| `player_shot` | IW4L → RW | M2 | A bullet the MW2 player fired while playing `pawn`: MW2's `weapon`, `from`/`to` (`[x, height, z]`, `to` where it stopped), and when it struck a pawn `target`, `part` (`head`/`body`) and MW2's `damage`. RimWorld shows the bullet and applies scaled damage, only while running. From M18 `part` is `head`, `neck`, `upper` (chest, shoulders, arms), `lower` (belly, hands) or `legs` on a standing person, measured on how they are drawn; `body` (anywhere) on anyone else |
| `player_struck` | IW4L → RW | M8 | RimWorld's bullet `shot` (a `shot`'s `id`) met the MW2 player, who plays `pawn`; `part` is `head` or `body`. RimWorld deals that bullet's own damage (and extra damage) to the colonist, once per bullet, paused or not |
| `terrain` | RW → IW4L | M3 | What stands on every cell of the map in view: `size` `[x, z]` and `cells`, one character a cell, row by row from the south edge (`z` 0), west to east. Sent on connect, when the map in view changes and when any cell changes (checked once a second) |
| `plants` | RW → IW4L | M3 | Every tree and bush on the map in view: `plants`, each with its cell `x`/`z`, `kind` (`pine`, `birch`, `oak`, `palm`, `cactus`, `dead`, `bush`; from M15 crops too, `crop_` and the plant's def, with `_young` while unripe) and `growth` (0 to 1, in tenths). Sent with `terrain` and when a plant comes, goes or grows a tenth |
| `shell` | RW → IW4L | M4 | Anything but a bullet fired on the map in view (mortar shells, grenades, rockets), as it leaves: `shooter`, `weapon`, `from`/`to` `[x, height, z]` in cells, `seconds` in flight at the current speed, `arc` when it flies over everything (mortars). From M20: `tex` (its own `_cut` picture in flight) and `size` in cells, `lob` (how many cells high RimWorld lobs it), `fuse` (seconds it lies where it landed before going off) |
| `explosion` | RW → IW4L | M4 | An explosion on the map in view as it starts: `x`/`z` (its cell's middle), `radius` in cells, `damage` (RimWorld's damage type: `Bomb`, `Flame`, `EMP`, `Smoke`, ...). RimWorld applies the damage; IW4L only shows and sounds it |
| `loot` | RW → IW4L | M4 | While a colonist is played, when it changes: `pawn`, `mass` carried of `capacity` (kg), its `kit` and `nearby` sources (`ground`, or a corpse or downed pawn's `id` and `label`), each a list of items: `id` (ThingID), `label`, `def`, `count`, `kind` (`weapon`/`apparel`/`item`), `mass` |
| `loot_take` | IW4L → RW | M4 | Take nearby `item` for `pawn`: a weapon is equipped (the held one drops), apparel worn (what it replaces drops), anything else carried, as much as the colonist can |
| `loot_drop` | IW4L → RW | M4 | Drop `item` from `pawn`'s kit at its feet |
| `roofs` | RW → IW4L | M5 | The roof over every cell of the map in view, in `terrain`'s order: `size` and `cells`, one character a cell (`.` none, `c` built, `r` thin rock, as over caves and a mountain's edge, `R` thick rock, deep in a mountain), and `hills`, how hilly the map's world tile is (0 unknown, 1 flat, 2 small hills, 3 large hills, 4 mountainous, 5 impassable). RimWorld stores no height for its rock; IW4L raises mountains from these. Sent on connect and when any roof changes (checked once a second) |
| `textures` | RW → IW4L | M5 | RimWorld's own art, saved as PNG files on this computer: `dir` and `names`, each picture `dir/name.png`, 128 pixels square and tinted as RimWorld draws it. `skins` and `buildings` name pictures by their index here. A name ending `_l15` is a linked wall's piece linking every way (its top); `_l11`, beside it, is the piece open to the south, whose bottom shows the wall's front face (M6). A name ending `_cut` is a cut-out picture (a pawn, an item) whose see-through parts stay see-through. The list only grows; sent again when it does |
| `skins` | RW → IW4L | M5 | The art of every cell, in `terrain`'s order: `size`, `walls` (each wall, door or smoothed stone) and `floors` (every cell's ground from M10, built floors only before; water has none), one character a cell: `.` for none, else `'0'` plus the picture's index in `textures` (past `~` too, from M6, up to U+D7FF) |
| `buildings` | RW → IW4L | M5 | Everything built on the map in view but walls, doors, rock and conduits: `buildings`, each with its `def`, the cells it covers `rect` (`[x0, z0, x1, z1]` inclusive), `rot` (0 north, 1 east, 2 south, 3 west), where its picture is drawn `at` (`[x, z]`, its middle) and its size `draw` (`[w, h]` in cells, before `turn`), its picture `tex` (index in `textures`, -1 none), `turn` (quarter turns clockwise the picture is drawn turned by), `flip` (mirrored, already in the PNG), `fill` (cover, 0 to 1) and `solid` (pawns cannot walk through it); from M15 optional `card`, its picture cut out (a `_cut` index, not mirrored) for what IW4L stands up as a picture rather than boxes (art, instruments, thrones, lecterns, altars, poppers; from M16 only art, whose 3D body IW4L cuts from the picture). Things still being built (frames, blueprints) are left out, here and in `terrain`, from M6. Sent when anything built changes |
| `items` | RW → IW4L | M6 | Everything lying on the map in view (not corpses): `items`, each with its `def`, cell `x`/`z`, picture `tex` (a `_cut` index in `textures`, -1 none) and `count` (stack size, 1 when left out). At most 5000, nearest the middle. Sent when any changes (checked once a second) |
| `view` | RW → IW4L | M9 | About ten times a second while MW2 has the focus: what RimWorld's camera shows around the MW2 player, for MW2's minimap. `size` pixels square, its middle at cell `x`/`z`, `cells` across, and `jpg`, a base64 JPEG whose first row is its southern one. RimWorld's own interface is not in it. From M15 `jpg` is empty and `file` names a shared file instead (`minimap.rgba` in the `textures` folder, sent about once a second): a 32 byte head (magic `RWV1`, frame count, odd while being written, `size`, `cells`, `x`, `z`) then `size` by `size` RGBA pixels, north row first, rewritten up to 60 times a second. No longer sent from M16: RimWorld's own window is the minimap (`overlay`) |
| `plant_art` | RW → IW4L | M10 | What each kind of plant looks like in RimWorld: `kinds`, each with a `kind` (a `plants` kind, or `grass` for the low cover on grassy cells) and `tex`, the `_cut` pictures IW4L may stand there. Sent when a kind's pictures are first seen |
| `doors` | RW → IW4L | M11 | How far every door has swung, as RimWorld has it now: `doors`, each with its cell `at` (`[x, z]`), how far it has swung `open` (0 shut, `steps` wide open) and which way its leaves slide `axis` (0 east and west, 1 north and south), and `steps`; from M16 a door wider than a cell also has `rect` (`[x0, z0, x1, z1]`), sent for each of its cells. Sent whenever any door moves. A door opens because the played colonist walked up to it, so RimWorld decides when; IW4L holds the MW2 player back until the way is clear |
| `overlay` | RW → IW4L | M16 | `shown`: whether RimWorld's own window is now on top of MW2's top left corner as its minimap (borderless, its interface hidden; while a colonist is played and MW2 is in front). IW4L hides its own minimap meanwhile |
| `costs` | RW → IW4L | M17 | `size` and `cells`, one character a cell in `terrain`'s order: `'0'` plus RimWorld's path cost of walking into the cell (ground, what stands there, snow; `PathGrid.CalculatedCostAt`), capped at 1000, or `'0'` plus 1001 where pawns cannot go. Sent when any changes. IW4L slows the played colonist as RimWorld would: its ticks a cell plus the cost, at most 450 |
| `fires` | RW → IW4L | M20 | Every fire on the map in view, on the ground or on someone: `fires` of `{x, z, size}` (cells, RimWorld's `fireSize`), at most 4 a second, when changed. IW4L burns MW2 fire there (big ones smoke) |
| `gas` | RW → IW4L | M20 | Gas over the map in view, per 2 by 2 cell patch: `gas` of `{at: [x, z], kind, density}` (`smoke`, `tox`, `rot`, `dust`; 1..255), at most once a second, when changed. IW4L hangs MW2 smoke there |
| `weather` | RW → IW4L | M21 | The weather on the map in view as RimWorld blends it: `rain` and `snow` (RimWorld's rates: 0 none, 1 steady, more for storms), `fog` (0 clear to 1; fog, haze, ash and sand weathers) and `wind` (RimWorld's wind speed factor), to a tenth, at most once a second, when changed. IW4L rains and snows around the player outside roofs and closes in the view |
| `filth` | RW → IW4L | M21 | The filth within 64 cells of the MW2 player: `filth` of `{tex, size, x, z, rot}`, one per splotch as RimWorld prints it (`tex` a `_cut` picture in `textures`, `size` cells, `rot` degrees), nearest first, at most 1500, every two seconds when changed. IW4L lays them flat and see-through |
| `flecks` | RW → IW4L | M21 | RimWorld's flecks made this frame within 40 cells of the MW2 player, at most 80: `flecks` of `{tex, x, z, y, size, grow, rot, spin, vx, vz, vy, fade_in, solid, fade_out, color, flat}` (cells, degrees and game seconds; see `FleckState`). IW4L moves, grows and fades each from there |
| `glow` | RW → IW4L | M12 | How brightly lamps, torches and other glowers light every roofed cell, in `terrain`'s order: `size` and `cells`, one hex digit a cell, `0` dark to `f` lit (RimWorld's own glow grid without daylight; `f` from where RimWorld counts a cell lit). Open sky is `0`; IW4L lights it fully. Sent when any changes |
| `use` | IW4L → RW | M12 | The MW2 player pressed E while playing `pawn`: the colonist works the nearest door (opens or shuts it, if RimWorld lets them) or switch (flicks it) within reach in front of them. From M18 also picks up the downed pawn nearest in front (RimWorld's drafted "Carry"), or puts down the one carried when no door or switch is in reach |
| `spectate` | IW4L → RW | M9 | About ten times a second while nobody is drafted: where the MW2 player flies, `x`/`z` in cells, so RimWorld's camera follows them |
| `rimworld_shown` | IW4L → RW | M9 | Tab in MW2 brought RimWorld's window up over MW2's; `back` is MW2's window as a string, for Tab in RimWorld to go back to |
| `menu` | IW4L → RW | M18 | MW2's Escape menu opened (`open` true) or closed: RimWorld hides its minimap window while it is open |
| `player_throw` | IW4L → RW | M20 | The MW2 player threw the played colonist `pawn`'s grenade (fire or G) at `to` `[x, z]` in cells, where they aimed on the ground: RimWorld throws its own grenade there at once (MW2 already waited RimWorld's aiming and cooldown) |
| `looks` | RW → IW4L | M7 | How each person on the map in view looks, so IW4L dresses their MW2 soldier the same: `looks`, each with the pawn's `id`, `skin` and `hair` colours (`[r, g, b]`, 0 to 255; `hair` null when bald) and `wear`, what they wear innermost first: `def`, `color` (as RimWorld draws it), `tex` (its picture facing south, a `_cut` index in `textures`, -1 none), `layer` (`OnSkin`, `Middle`, `Shell`, `Belt`, `Overhead`) and `parts` (body part groups it covers: `Torso`, `Legs`, `Arms`, `Shoulders`, `Hands`, `Feet`, `FullHead`, `UpperHead`, ...). Sent when anyone's changes (checked once a second) |

Terrain codes: `.` soil, `,` sand, `:` stony ground (gravel, rough stone, ice), `=` built floor
or bridge, `~` shallow water, `O` deep water, `#` natural rock, `W` wall (from M5 only walls; before, anything built that
fills its cell), `+` door, `c` cover (sandbags, barricades, furniture), `M` anything else built that is solid or
fills its cell but is not a wall (machines, turrets, coolers; M5, modelled from `buildings`; fences from M17, as RimWorld keeps people out of them), `T` tree, `g` grass (ground
with grass or other low plants on it; not crops, from M15). Smoothed stone walls are `W` and collapsed rock `#` (M15).
Deep water holds the MW2 player back, as RimWorld's pawns cannot cross it (M15). IW4L reads any other character as soil.

Planned: `pawn_downed`.

## Units

Positions are RimWorld cell coordinates (floats, smoothed from `DrawPos`), `z` growing north;
`y` is unused except in `shot.from`/`shot.to`, where it is a height in cells. On the `rimworld:flat`
map one cell is two blocks across (from M6; one before) and heights stay in blocks (one block is 36 IW4
units, about half an MW2 soldier's height). Map origin is the middle of the map, and RimWorld north is map +Y.
A sprinting MW2 player moves as fast as an uninjured drafted colonist walking to a point (4.6 cells a second),
slower through trees as RimWorld's pathing is.

## FPS fork additions

All additive: the original IW4L side ignores fields and messages it does not know.

| `t` | Direction | Meaning |
|---|---|---|
| `hello` | client → RW | `side` is `fps` for the FPS client (`client/`) |
| `snapshot` | RW → client | While a colonist is played: `player_health` (RimWorld's summary health, 0 to 1), `player_armor` (sharp armour rating, 0 to 2) and `player_weapon` (the held weapon's label), for the status bar; `player_gun.range`, how far the gun shoots in cells (the client's bullets go no further) |
| `weather` | RW → client | `sky`: RimWorld's sky glow, 0 night to 1 noon. The client darkens the open sky and outdoors by it |
| `player_shot` | client → RW | `damage` is optional now: RimWorld deals the colonist's own bullet damage (and its extra damage) for a hit, rolled as RimWorld rolls it; `damage` is used only for a gun without a bullet |
| `player_melee` | client → RW | The played colonist `pawn` attacks `target` in melee (fire with a melee weapon or bare hands, at the pawn in front). RimWorld makes the attack with the colonist's own melee verbs (hit chance, damage, body part, cooldown), only when `target` is in reach |

### More fork messages

| Line | Direction | Meaning |
| --- | --- | --- |
| `texture` `{i, png}` | RimWorld → client | Picture `i` of the `textures` names as a base64 PNG, read from the game's and mods' loaded textures. Sent before the `textures` line that names it; no files are written, and `textures`' `dir` is empty. |
| `status` `{pawn, health, pain, bleeding, bleed_hours?, mood?, capacities, parts, conditions}` | RimWorld → client | The played colonist's health as the health tab reckons it, at most every half second when it changes. |
| `health_card` `{pawn, w, h, png}` | RimWorld → client | The played colonist's Health tab as RimWorld (and any mod that changes it, such as Nice Health Tab) draws it, a base64 PNG, about once a second when it changes. |
| `minimap` `{x?, y?, size?, shown, round, zoom?}` | client → RimWorld | Where the client's minimap widget is (client window pixels); on Windows RimWorld puts its own window there as the minimap. |
