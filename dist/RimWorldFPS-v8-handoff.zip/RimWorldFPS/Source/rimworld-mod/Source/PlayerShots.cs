using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using RimWorld;
using UnityEngine;
using Verse;
using Verse.Sound;

namespace RimWorldFPS
{
    /// <summary>
    /// M2: the FPS player's bullets. Each one is shown in RimWorld as the played colonist's own
    /// bullet flying where the client sent it (a harmless look-alike), and a hit damages the pawn the client
    /// struck, as the colonist's gun would. Only while RimWorld runs: nothing happens paused.
    /// FPS fork: a hit deals the gun's own bullet damage, as RimWorld rolls it, not a scaled
    /// MW2 number; the client's <c>damage</c> is only used for a gun without a bullet.
    /// </summary>
    public static class PlayerShots
    {
        /// <summary>The client's damage for a hit, times this, when the gun has no bullet of its
        /// own to take the damage from.</summary>
        public const float DamageScale = 0.3f;

        /// <summary>Look-alike bullets in flight: they land without touching anything.</summary>
        private static readonly HashSet<Projectile> lookAlikes = new HashSet<Projectile>();

        internal static bool IsLookAlike(Projectile projectile) => lookAlikes.Contains(projectile);

        internal static void Forget(Projectile projectile) => lookAlikes.Remove(projectile);

        /// <summary>A <c>player_shot</c>: <paramref name="from"/> and <paramref name="to"/> are
        /// RimWorld <c>x</c> and <c>z</c>; <paramref name="part"/> is where it struck (<see cref="Part"/>).</summary>
        public static void Fired(string id, Vector3 from, Vector3 to, string target, string part, float damage)
        {
            if (Find.TickManager.Paused) return;
            Map map = PawnSnapshot.MapInView();
            Pawn shooter = PlayerPawn.Current(map);
            if (shooter == null || shooter.ThingID != id) return;
            Thing gun = shooter.equipment?.Primary;
            VerbProperties verb = gun?.def?.Verbs?.FirstOrDefault();
            ShowBullet(shooter, gun, verb, from, to, map);
            if (target == null) return;
            Pawn victim = map.mapPawns.AllPawnsSpawned.FirstOrDefault(p => p.ThingID == target);
            if (victim == null || victim.Dead) return;
            ProjectileProperties bullet = verb?.defaultProjectile?.projectile;
            float amount = bullet != null && gun != null ? bullet.GetDamageAmount(gun) : damage * DamageScale;
            if (amount <= 0f) return;
            float armorPenetration = bullet?.GetArmorPenetration(gun) ?? 0.15f;
            float angle = (victim.Position - shooter.Position).AngleFlat;
            BodyPartRecord struck = Part(victim, part);
            var hit = new DamageInfo(bullet?.damageDef ?? DamageDefOf.Bullet, Mathf.Max(1f, amount), armorPenetration,
                angle, shooter, struck, gun?.def, intendedTarget: victim);
            victim.TakeDamage(hit);
            // As RimWorld's own bullet: its extra damage (an EMP round's, a charge lance's burn).
            if (bullet?.extraDamages == null) return;
            foreach (ExtraDamage extra in bullet.extraDamages)
            {
                if (victim.Dead || !Rand.Chance(extra.chance)) continue;
                victim.TakeDamage(new DamageInfo(extra.def, extra.amount, extra.AdjustedArmorPenetration(), angle,
                    shooter, struck, gun?.def, intendedTarget: victim));
            }
        }

        /// <summary>Where on <paramref name="victim"/> the client's bullet struck (M18), as RimWorld's
        /// body part: <c>head</c> one of the head's outer parts (head, eyes, ears, nose, jaw),
        /// <c>neck</c> the neck, <c>upper</c> the chest, shoulders or arms, <c>lower</c> the
        /// belly or hands, <c>legs</c> the legs and feet. Chosen by size, as RimWorld picks among the
        /// parts at a height. Null, for RimWorld to choose anywhere, for <c>body</c> or a body
        /// without such parts.</summary>
        internal static BodyPartRecord Part(Pawn victim, string part)
        {
            if (part == null || victim?.health?.hediffSet == null) return null;
            var parts = victim.health.hediffSet.GetNotMissingParts(depth: BodyPartDepth.Outside).ToList();
            bool InHead(BodyPartRecord p) => Under(p, BodyPartDefOf.Head);
            IEnumerable<BodyPartRecord> pick;
            switch (part)
            {
                case "head": pick = parts.Where(InHead); break;
                case "neck": pick = parts.Where(p => p.def == BodyPartDefOf.Neck); break;
                case "upper":
                    pick = parts.Where(p => p.def == BodyPartDefOf.Torso
                        || Under(p, BodyPartDefOf.Shoulder) && p.height != BodyPartHeight.Bottom);
                    break;
                case "lower":
                    pick = parts.Where(p => p.def == BodyPartDefOf.Torso
                        || Under(p, BodyPartDefOf.Arm) && p.height == BodyPartHeight.Bottom);
                    break;
                case "legs": pick = parts.Where(p => Under(p, BodyPartDefOf.Leg)); break;
                default: return null;
            }
            var list = pick.ToList();
            if (list.Count == 0) return null;
            return list.RandomElementByWeight(p => Mathf.Max(0.001f, p.coverageAbs));
        }

        private static bool Under(BodyPartRecord part, BodyPartDef def)
        {
            for (BodyPartRecord p = part; p != null; p = p.parent)
                if (p.def == def) return true;
            return false;
        }

        private static void ShowBullet(Pawn shooter, Thing gun, VerbProperties verb, Vector3 from, Vector3 to, Map map)
        {
            verb?.soundCast?.PlayOneShot(new TargetInfo(shooter.Position, map));
            ThingDef bulletDef = verb?.defaultProjectile;
            if (bulletDef == null) return;
            var land = new IntVec3((int)to.x, 0, (int)to.z);
            if (!land.InBounds(map)) land = land.ClampInsideMap(map);
            if (lookAlikes.Count > 512) lookAlikes.RemoveWhere(p => p.Destroyed);
            var bullet = (Projectile)GenSpawn.Spawn(bulletDef, shooter.Position, map);
            lookAlikes.Add(bullet);
            bullet.Launch(shooter, new Vector3(from.x, 0f, from.z), land, land, ProjectileHitFlags.None, false, gun);
        }
    }

    /// <summary>A look-alike bullet only disappears where it lands.</summary>
    [HarmonyPatch(typeof(Bullet), "Impact")]
    internal static class LookAlikeBulletImpact
    {
        private static bool Prefix(Bullet __instance)
        {
            if (!PlayerShots.IsLookAlike(__instance)) return true;
            PlayerShots.Forget(__instance);
            if (!__instance.Destroyed) __instance.Destroy();
            return false;
        }
    }
}
