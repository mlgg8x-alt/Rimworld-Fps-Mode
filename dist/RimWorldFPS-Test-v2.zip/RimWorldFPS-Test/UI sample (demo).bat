start "" "%~dp0RimFpsClient.exe" --demo --edit
